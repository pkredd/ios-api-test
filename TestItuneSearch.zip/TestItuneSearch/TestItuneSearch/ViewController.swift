//
//  ViewController.swift
//  TestItuneSearch
//
//  Created by Vani on 4/8/20.
//  Copyright © 2020 Test. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UISearchBarDelegate, UITableViewDelegate, UITableViewDataSource {
    
    var tableViewData = [String : [[String: Any]]]()
    var favData = [[String: Any]]()
    var kindsArray = [String]()
    
    var searchBar = UISearchBar()
    var dataTblView  = UITableView()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        addUIControls()
        loadFavFromUserDefaults()
    }
    
    func addUIControls()
    {
        searchBar.frame = CGRect(x: 0, y: 10, width: self.view.frame.width, height: 50)
        searchBar.showsCancelButton = true
        searchBar.delegate = self
        self.view.addSubview(searchBar)
        
        dataTblView.frame = CGRect(x: 0, y: 65, width: self.view.frame.width, height: self.view.frame.height - 70)
        dataTblView.dataSource = self
        dataTblView.delegate = self
        dataTblView.rowHeight = 65
        self.view.addSubview(dataTblView)
        
    }
    override func viewWillAppear(_ animated: Bool) {
        
    }
    
    //MARK:- Serach Bar Delegate methods
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
        
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        
        self.searchBar.resignFirstResponder()
        searchBar.text = ""
        prepareTableData([[String: Any]]())
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        self.searchBar.resignFirstResponder()
        if let txt = searchBar.text {
            searchiTunes(txt)
        }
    }
    
    //MARK:- Tableview data methods
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return getData(section).count
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return kindsArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: UITableViewCell = UITableViewCell(style: UITableViewCell.CellStyle.subtitle, reuseIdentifier: "MyTestCell")
        cell.selectionStyle = UITableViewCell.SelectionStyle.none
        let obj = getData(indexPath.section)[indexPath.row]
        
        var iconImageView : UIImageView?
        var titleLbl : UILabel?
        var generType : UILabel?
        var generLbl : UILabel?
        var linkBtn : CellButton?
        var favbtn : CellButton?
        
        if let img = cell.contentView.viewWithTag(1001) as? UIImageView {
            iconImageView = img
        }
        else {
            iconImageView = UIImageView.init(frame: CGRect(x: 5, y: 5, width: 60 , height: 60))
            cell.contentView.addSubview(iconImageView!)
            iconImageView?.contentMode = .scaleAspectFit
            iconImageView?.tag = 1001
        }
        
        if let lbl = cell.contentView.viewWithTag(1002) as? UILabel {
            titleLbl = lbl
        }
        else {
            let x = (iconImageView?.frame.maxX)! + 5
            titleLbl = UILabel.init(frame: CGRect(x: x, y: 5, width: (tableView.frame.width - x - 10)  , height: 20))
            cell.contentView.addSubview(titleLbl!)
            titleLbl?.tag = 1002
            titleLbl?.font = UIFont.boldSystemFont(ofSize: 11)
        }
        
        if let lbl = cell.contentView.viewWithTag(1003) as? UILabel {
            generType = lbl
        }
        else {
            let x = (iconImageView?.frame.maxX)! + 5
            let y = (titleLbl?.frame.maxY)! + 5
            generType = UILabel.init(frame: CGRect(x: x, y: y, width: 35  , height: 15))
            cell.contentView.addSubview(generType!)
            generType?.text = "Genre : "
            generType?.font = UIFont.systemFont(ofSize: 9)
            generType?.tag = 1003
        }
        
        if let lbl = cell.contentView.viewWithTag(1004) as? UILabel {
            generLbl = lbl
        }
        else {
            let x = (generType?.frame.maxX)! + 5
            let y = (titleLbl?.frame.maxY)! + 5
            generLbl = UILabel.init(frame: CGRect(x: x, y: y, width: 130  , height: 15))
            cell.contentView.addSubview(generLbl!)
            generLbl?.font = UIFont.boldSystemFont(ofSize: 9)
            generLbl?.tag = 1004
        }
        
        if let btn = cell.contentView.viewWithTag(1005) as? CellButton {
            linkBtn = btn
        }
        else {
            let x = (iconImageView?.frame.maxX)! + 5
            let y = (generLbl?.frame.maxY)! + 5
            linkBtn = CellButton.init(frame: CGRect(x: x, y: y, width: (tableView.frame.width - x - 10) , height: 15))
            cell.contentView.addSubview(linkBtn!)
            linkBtn?.setTitleColor(.blue, for: .normal)
            linkBtn?.titleLabel?.font = UIFont.systemFont(ofSize: 9.0)
            linkBtn?.addTarget(self, action: #selector(linkBtnTapped(_:)), for: .touchUpInside)
        }
        
        if let btn = cell.contentView.viewWithTag(1006) as? CellButton {
            favbtn = btn
        }
        else {
            let x = tableView.frame.width - 30
            let y = (generLbl?.frame.minY)! - 5
            favbtn = CellButton.init(frame: CGRect(x: x, y: y, width: 25 , height: 25))
            cell.contentView.addSubview(favbtn!)
            favbtn?.addTarget(self, action: #selector(favBtnTapped(_:)), for: .touchUpInside)
        }
        let sts = getFavoriteSts(obj)
        if sts == true {
            favbtn?.setImage(UIImage.init(named: "like"), for: .normal)
        }
        else {
            favbtn?.setImage(UIImage.init(named: "like_unfilled"), for: .normal)
        }
        linkBtn?.indexPath = indexPath
        favbtn?.indexPath = indexPath
        titleLbl?.text = obj ["artistName"] as? String ?? ""
        generLbl?.text = obj ["primaryGenreName"] as? String ?? ""
        linkBtn?.setTitle(obj ["trackViewUrl"] as? String, for: .normal)
        if let imgURL = obj["artworkUrl100"] as? String {
            iconImageView?.sd_setImage(with: URL.init(string: imgURL), placeholderImage: UIImage.init(named: "audio"), options: .progressiveLoad, completed: { (img, err, type, url) in
                
            })
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return kindsArray[section]
    }
    
    func getData(_ section: Int) -> [[String: Any]]
    {
        let type = kindsArray[section]
        return tableViewData[type]!
    }
    
    func getFavoriteSts(_ obj: [String : Any]) -> Bool
    {
        if let trackId = obj ["trackId"] as? Int {
            let arr = favData.filter({$0["trackId"] as? Int  == trackId})
            if arr.count > 0 {
                return true
            }
        }
        return false
    }
    
    //MARK:- UIButton Actions
    @objc func linkBtnTapped(_ btn: CellButton){
        print("linkBtnTapped",btn.indexPath)
        if let indexPath = btn.indexPath{
            let obj = getData(indexPath.section)[indexPath.row]
            if let url = obj["trackViewUrl"] as? String{
                UIApplication.shared.open(URL.init(string: url)!, options: [:]) { (done) in
                    
                }
            }
        }
    }
    @objc func favBtnTapped(_ btn: CellButton) {
        print("favBtnTapped",btn.indexPath)
        
        if let indexPath = btn.indexPath{
            let obj = getData(indexPath.section)[indexPath.row]
            let sts = getFavoriteSts(obj)
            if sts == true {
                favData.removeAll(where: {$0["trackId"] as? Int == obj ["trackId"] as? Int})
            }
            else {
                favData.append(obj)
            }
        }
        dataTblView.reloadData()
        updateFavInUserDefauls()
    }
    
    //MARK:- Update User defaults
    func updateFavInUserDefauls(){
        UserDefaults.standard.set(favData, forKey: "Fav_Data")
        UserDefaults.standard.synchronize()
    }
    func loadFavFromUserDefaults() {
        if let data = UserDefaults.standard.object(forKey: "Fav_Data"), let obj = data as? [[String : Any]]{
            self.favData = obj
        }
        var data = [[String : Any]]()
        self.prepareTableData(data)
    }
    func searchiTunes(_ txt: String)
    {
        let apiObj = APICall.instance
        apiObj.performAPIcallWith(urlStr: txt, methodName: .get, json: nil)
        apiObj.successAPI = {(result) -> () in
            print("result:",result)
            if let res = result
            {
                DispatchQueue.main.async {
                    self.readResponse(res)
                }
                
            }
        }
        apiObj.failureAPI = {(result) -> () in
            print("result:",result?.error)
            DispatchQueue.main.async {
                
            }
        }
    }
    
    func readResponse(_ result: APIResult){
        if let data = result.data
        {
            let json = try? JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.allowFragments)
            if let dict = json, dict is [String : Any], let obj = dict as?  [String : Any]
            {
                if let array = obj ["results"], let resultsArray = array as? [[String : Any]]
                {
                    self.prepareTableData(resultsArray)
                }
            }
        }
    }
    
    func prepareTableData(_ results: [[String : Any]]) {
        var resultsArray = results
        if resultsArray.count == 0 {
            resultsArray.append(contentsOf: favData)
        }
        else {
            for obj in favData {
                
                if let trackId = obj ["trackId"] as? Int {
                    let arr = resultsArray.filter({$0["trackId"] as? Int  == trackId})
                    if arr.count == 0 {
                        resultsArray.insert(obj, at: 0)
                    }
                }
            }
        }
        var kinds = resultsArray.map({$0["kind"] as? String})
        kinds = kinds.removeDuplicates()
        kinds = kinds.filter({$0 != nil})
        self.kindsArray = kinds as! [String]
        for type in self.kindsArray {
            let arr = resultsArray.filter({$0["kind"] as? String == type})
            self.tableViewData[type] = arr
        }
        DispatchQueue.main.async {
            self.dataTblView.reloadData()
        }
    }
}

extension Array where Element:Equatable {
    func removeDuplicates() -> [Element] {
        var result = [Element]()
        
        for value in self {
            if result.contains(value) == false {
                result.append(value)
            }
        }
        
        return result
    }
    mutating func removeObject(_ obj: Element){
        if let index  = self.index(of: obj){
            self.remove(at: index)
        }
    }
}


//MARK:- Custom Button

class CellButton : UIButton {
    var indexPath: IndexPath?
}
